from fastapi import FastAPI, APIRouter
from typing import Union
from config.database import conn
from models.models import datos
from schema.dato import Dato
from sqlalchemy.sql import text
#from schema.dato import Dato

appRouter = APIRouter()

@appRouter.get("/datos")
async def get_datos():
     return conn.execute(datos.select()).fetchall()

# @appRouter.get("/items/{item_id}")
# async def read_dato(dato_id):
#     return conn.execute(datos.select()).inserted_primary_key(dato_id)

# @appRouter.post("/datos/")
# async def create_datos(dato: Dato):
#     new_dato = {"ID": dato.id, "Temperatura": dato.temperatura, "Humedad": dato.humedad}
#     conn.execute(datos.insert(new_dato))

#max_hum    min_temp    min_hum     temp_max_by_qty     hum_max_by_qty     temp_min_by_qty     hum_min_by_qty

@appRouter.get("/maxtemp")
async def max_temp():
    
    return conn.execute("SELECT * FROM datos ORDER BY Temperatura DESC LIMIT 1").fetchall()

@appRouter.get("/maxhum")
async def max_hum():

    return conn.execute("SELECT * FROM datos ORDER BY Humedad DESC LIMIT 1").fetchall()
    
@appRouter.get("/mintemp")
async def min_temp():
    return conn.execute("SELECT * FROM datos ORDER BY Temperatura ASC LIMIT 1").fetchall()

@appRouter.get("/minhum")
async def min_hum():

    return conn.execute("SELECT * FROM datos ORDER BY Humedad ASC LIMIT 1").fetchall()